---
title: Curriculum Vitæ
layout: cv
actions:
  - label: "Download as PDF"
    icon: pdf
    url: "#pdf-asset"
---